<?php
$db = mysqli_connect("localhost", "sammeyin_android", "Sagar12345#", "sammeyin_login") or die ("Failed to connect");

?>